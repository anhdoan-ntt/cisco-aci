./automation/build-artifacts.sh
